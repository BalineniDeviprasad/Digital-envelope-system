# Advanced-Digital-Envelope-System

The digital envelope system is the technique that is used to protect the message through encryption.
It uses two types of encryption scheme to secure a message.
First, the message itself is encoded using symmetric encryption and then the session key is also encrypted using public-key encryption.
But the original digital envelope system cannot provide the features of the data authentication and data integrity.
By using a hash algorithm, these features can be obtained. 
This is the demonstration of the advanced digital envelope system by using AES (Advanced Encryption Standard) as symmetric algorithm, RSA as asymmetric algorithm and SHA-256 as hash algorithm. This system is developed by using Python3.
